# Wedecide Management

The best out there you can trust, we secure and monitor every votes casted into the database. A scaleble application that ease election and contest.

## Visit
[Wedecide Official Site](https://wedecide.com);

### About us

[Find out about us here => ](https://wedecide.com/about-us)